# gauge_detection > train_val
https://universe.roboflow.com/evankim9903-gmail-com/gauge_detection

Provided by a Roboflow user
License: CC BY 4.0

